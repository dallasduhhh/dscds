# Unblock Youku Firefox Addon

This addon will help users access their web services while travelling outside mainland China.

You can find this addon on Mozilla AMO at http://bit.ly/unblock-youku-firefox

This project is forked from [Unblock Youku Chrome extension](https://github.com/whuhacker/Unblock-Youku).

## Disclaimer

Using/installing this software, you agree that it is only for study purposes and its authors take no responsibilities for any consequences.

## License

The source code is released under [AGPL v3](http://www.gnu.org/licenses/agpl-3.0.html) or (at your option) any later version.

## Credits

[@zhuzhuor](https://github.com/zhuzhuor) - Author of the original Chrome extension
