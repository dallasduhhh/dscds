GAbroad = false;
contentFrame.GAbroad = false;
window.alert(GAbroad);